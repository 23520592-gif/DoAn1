# ============================================================
# setup_b4.tcl - Tao project B4 (dualcore + coherence) tren Vivado
# Chay: mo Vivado -> Tcl Console -> source E:/DoAn1/setup_b4.tcl
# Muc tieu B4: ELABORATE sach (he hinh thanh). Chua can chay sim.
# ============================================================

# --- 1. Tao project ---
create_project ibex_dualcore_v3 E:/DoAn1/ibex_dualcore_v3 -part xc7a35tcsg324-1 -force
set_property target_language Verilog [current_project]
set_property simulator_language Mixed [current_project]

# --- 2. File coherence + top v3 (cua ban) ---
import_files -norecurse [list \
  E:/DoAn1/ibex_coherence_pkg.sv \
  E:/DoAn1/ibex_l1_cache.sv \
  E:/DoAn1/ibex_directory_controller.sv \
  E:/DoAn1/ibex_coh_subsystem.sv \
  E:/DoAn1/ibex_dualcore_top_v3.sv \
]

# --- 3. File lowRISC (ibex core + prim) - dung add_files (tham chieu, khong copy) ---
add_files -norecurse [list \
  E:/DoAn1/ibex/vendor/lowrisc_ip/ip/prim/rtl/prim_pkg.sv \
  E:/DoAn1/ibex/vendor/lowrisc_ip/ip/prim/rtl/prim_ram_1p_pkg.sv \
  E:/DoAn1/ibex/vendor/lowrisc_ip/ip/prim/rtl/prim_secded_pkg.sv \
  E:/DoAn1/ibex/vendor/lowrisc_ip/ip/prim_generic/rtl/prim_generic_ram_1p.sv \
  E:/DoAn1/ibex/rtl/ibex_pkg.sv \
  E:/DoAn1/ibex/rtl/ibex_alu.sv \
  E:/DoAn1/ibex/rtl/ibex_branch_predict.sv \
  E:/DoAn1/ibex/rtl/ibex_compressed_decoder.sv \
  E:/DoAn1/ibex/rtl/ibex_controller.sv \
  E:/DoAn1/ibex/rtl/ibex_core.sv \
  E:/DoAn1/ibex/rtl/ibex_counter.sv \
  E:/DoAn1/ibex/rtl/ibex_cs_registers.sv \
  E:/DoAn1/ibex/rtl/ibex_csr.sv \
  E:/DoAn1/ibex/rtl/ibex_decoder.sv \
  E:/DoAn1/ibex/rtl/ibex_dummy_instr.sv \
  E:/DoAn1/ibex/rtl/ibex_ex_block.sv \
  E:/DoAn1/ibex/rtl/ibex_fetch_fifo.sv \
  E:/DoAn1/ibex/rtl/ibex_icache.sv \
  E:/DoAn1/ibex/rtl/ibex_id_stage.sv \
  E:/DoAn1/ibex/rtl/ibex_if_stage.sv \
  E:/DoAn1/ibex/rtl/ibex_load_store_unit.sv \
  E:/DoAn1/ibex/rtl/ibex_lockstep.sv \
  E:/DoAn1/ibex/rtl/ibex_multdiv_fast.sv \
  E:/DoAn1/ibex/rtl/ibex_multdiv_slow.sv \
  E:/DoAn1/ibex/rtl/ibex_pmp.sv \
  E:/DoAn1/ibex/rtl/ibex_prefetch_buffer.sv \
  E:/DoAn1/ibex/rtl/ibex_register_file_ff.sv \
  E:/DoAn1/ibex/rtl/ibex_register_file_fpga.sv \
  E:/DoAn1/ibex/rtl/ibex_top.sv \
  E:/DoAn1/ibex/rtl/ibex_wb_stage.sv \
  E:/DoAn1/prim_buf.sv \
  E:/DoAn1/prim_clock_gating.sv \
]

# --- 4. Dat file type SystemVerilog cho tat ca .sv ---
foreach f [get_files *.sv] { set_property file_type SystemVerilog $f }

# --- 5. Include dir (4 thu muc - lay tu project sharedbus da chay duoc) ---
#   ibex/rtl                          : cac .svh cua core
#   prim/rtl                          : prim_assert.sv + macros
#   prim_generic/rtl                  : prim generic
#   dv/sv/dv_utils                    : dv_fcov_macros.svh (coverage macro)
set_property include_dirs [list \
  E:/DoAn1/ibex/rtl \
  E:/DoAn1/ibex/vendor/lowrisc_ip/ip/prim/rtl \
  E:/DoAn1/ibex/vendor/lowrisc_ip/ip/prim_generic/rtl \
  E:/DoAn1/ibex/vendor/lowrisc_ip/dv/sv/dv_utils \
] [get_filesets sources_1]

# --- 6. Set top + cap nhat thu tu compile (Vivado tu sap package truoc) ---
set_property top ibex_dualcore_top_v3 [get_filesets sources_1]
update_compile_order -fileset sources_1

# --- 7. Elaborate kiem tra (muc tieu B4) ---
puts "============================================"
puts " Setup xong. Chay lenh sau de elaborate:"
puts "   synth_design -rtl -name rtl_b4 -top ibex_dualcore_top_v3"
puts " Neu chay toi noi khong loi -> B4 DAT."
puts "============================================"
