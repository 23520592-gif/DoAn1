# ============================================================
# setup_b5_full.tcl
# Tao lai project B5 sach tu dau: RTL + coherence + core that + testbench
# Da bao gom: include_dirs cho CA HAI fileset, debug level, top sim.
#
# TRUOC KHI CHAY (thu cong):
#   1. Dong het file trong E:/DoAn1 dang mo o editor
#   2. Task Manager: kill xsim.exe / xelab.exe / xvlog.exe / xsc.exe con sot
#   3. Xoa tay thu muc E:/DoAn1/ibex_dualcore_v3 (neu con)
#
# CHAY: Vivado -> Tcl Console -> source E:/DoAn1/setup_b5_full.tcl
# ============================================================

# --- Dong project cu neu dang mo ---
catch { close_sim -force }
catch { close_project }

# --- 1. Tao project moi ---
create_project ibex_dualcore_v3 E:/DoAn1/ibex_dualcore_v3 -part xc7a35tcsg324-1 -force
set_property target_language Verilog [current_project]
set_property simulator_language Mixed [current_project]
# Tat che do quan ly source tu dong de tranh Vivado doan sai compile order
set_property source_mgmt_mode All [current_project]

# --- 2. File coherence + top v3 (cua ban) -> sources_1 ---
add_files -norecurse [list \
  E:/DoAn1/ibex_coherence_pkg.sv \
  E:/DoAn1/ibex_l1_cache.sv \
  E:/DoAn1/ibex_directory_controller.sv \
  E:/DoAn1/ibex_coh_subsystem.sv \
  E:/DoAn1/ibex_dualcore_top_v3.sv \
]

# --- 3. File lowRISC (ibex core + prim) -> sources_1 ---
add_files -norecurse [list \
  E:/DoAn1/ibex/vendor/lowrisc_ip/ip/prim/rtl/prim_pkg.sv \
  E:/DoAn1/ibex/vendor/lowrisc_ip/ip/prim/rtl/prim_ram_1p_pkg.sv \
  E:/DoAn1/ibex/vendor/lowrisc_ip/ip/prim/rtl/prim_secded_pkg.sv \
  E:/DoAn1/ibex/vendor/lowrisc_ip/ip/prim_generic/rtl/prim_generic_ram_1p.sv \
  E:/DoAn1/ibex/rtl/ibex_pkg.sv \
  E:/DoAn1/ibex/rtl/ibex_alu.sv \
  E:/DoAn1/ibex/rtl/ibex_branch_predict.sv \
  E:/DoAn1/ibex/rtl/ibex_compressed_decoder.sv \
  E:/DoAn1/ibex/rtl/ibex_controller.sv \
  E:/DoAn1/ibex/rtl/ibex_core.sv \
  E:/DoAn1/ibex/rtl/ibex_counter.sv \
  E:/DoAn1/ibex/rtl/ibex_cs_registers.sv \
  E:/DoAn1/ibex/rtl/ibex_csr.sv \
  E:/DoAn1/ibex/rtl/ibex_decoder.sv \
  E:/DoAn1/ibex/rtl/ibex_dummy_instr.sv \
  E:/DoAn1/ibex/rtl/ibex_ex_block.sv \
  E:/DoAn1/ibex/rtl/ibex_fetch_fifo.sv \
  E:/DoAn1/ibex/rtl/ibex_icache.sv \
  E:/DoAn1/ibex/rtl/ibex_id_stage.sv \
  E:/DoAn1/ibex/rtl/ibex_if_stage.sv \
  E:/DoAn1/ibex/rtl/ibex_load_store_unit.sv \
  E:/DoAn1/ibex/rtl/ibex_lockstep.sv \
  E:/DoAn1/ibex/rtl/ibex_multdiv_fast.sv \
  E:/DoAn1/ibex/rtl/ibex_multdiv_slow.sv \
  E:/DoAn1/ibex/rtl/ibex_pmp.sv \
  E:/DoAn1/ibex/rtl/ibex_prefetch_buffer.sv \
  E:/DoAn1/ibex/rtl/ibex_register_file_ff.sv \
  E:/DoAn1/ibex/rtl/ibex_register_file_fpga.sv \
  E:/DoAn1/ibex/rtl/ibex_top.sv \
  E:/DoAn1/ibex/rtl/ibex_wb_stage.sv \
  E:/DoAn1/prim_buf.sv \
  E:/DoAn1/prim_clock_gating.sv \
]

# --- 4. Testbench -> sim_1 ---
add_files -fileset sim_1 -norecurse E:/DoAn1/ibex_dualcore_v3_tb.sv

# --- 5. File type SystemVerilog cho TAT CA .sv ---
foreach f [get_files *.sv] { set_property file_type SystemVerilog $f }

# --- 6. Include dir cho CA HAI fileset (quan trong: ASSERT_* macro) ---
set inc [list \
  E:/DoAn1/ibex/rtl \
  E:/DoAn1/ibex/vendor/lowrisc_ip/ip/prim/rtl \
  E:/DoAn1/ibex/vendor/lowrisc_ip/ip/prim_generic/rtl \
  E:/DoAn1/ibex/vendor/lowrisc_ip/dv/sv/dv_utils \
]
set_property include_dirs $inc [get_filesets sources_1]
set_property include_dirs $inc [get_filesets sim_1]

# --- 7. Set top ---
set_property top ibex_dualcore_top_v3 [get_filesets sources_1]
set_property top ibex_dualcore_v3_tb  [get_filesets sim_1]

# --- 8. Debug level cho phep nap IMEM bang hierarchical reference ---
set_property -name {xsim.elaborate.xelab.more_options} -value {-debug all} -objects [get_filesets sim_1]

puts "============================================"
puts " Setup B5 xong."
puts " Kiem tra so file sim thay duoc (mong doi ~36):"
puts "   llength \[get_files -compile_order sources -used_in simulation\]"
puts " Roi chay:"
puts "   launch_simulation"
puts "   run -all"
puts "============================================"
