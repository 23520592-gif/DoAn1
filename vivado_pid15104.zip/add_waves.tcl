# ============================================================
# add_waves.tcl - Them signal B2 Coherence vao waveform (Vivado xsim)
# ------------------------------------------------------------
# Cach dung:
#   1) Flow Navigator -> Run Simulation -> Run Behavioral Simulation
#      (hoac go: launch_simulation)
#   2) Trong Tcl Console: source E:/DoAn1/add_waves.tcl
#   3) restart ; run 500 ns
# ============================================================

# Xoa waveform cu (neu can lam lai sach). Boc catch de khong loi khi chua co wave.
catch { remove_wave -of [get_wave_config] [get_waves *] }

# ---------- Testbench Top Signals ----------
add_wave_divider "Testbench Top Signals"
add_wave {/ibex_coherence_tb/clk}
add_wave {/ibex_coherence_tb/rst_n}
add_wave {/ibex_coherence_tb/core_req}
add_wave {/ibex_coherence_tb/core_gnt}
add_wave {/ibex_coherence_tb/core_addr}
add_wave {/ibex_coherence_tb/core_we}
add_wave {/ibex_coherence_tb/core_be}
add_wave {/ibex_coherence_tb/core_wdata}
add_wave {/ibex_coherence_tb/core_rvalid}
add_wave {/ibex_coherence_tb/core_rdata}

# ---------- Coherence Bus: Cache <-> Directory ----------
add_wave_divider "Coherence Bus Cache <-> Directory"
add_wave {/ibex_coherence_tb/dut/req_valid}
add_wave {/ibex_coherence_tb/dut/req_type}
add_wave {/ibex_coherence_tb/dut/req_addr}
add_wave {/ibex_coherence_tb/dut/req_data}
add_wave {/ibex_coherence_tb/dut/req_gnt}
add_wave {/ibex_coherence_tb/dut/resp_valid}
add_wave {/ibex_coherence_tb/dut/resp_msg}
add_wave {/ibex_coherence_tb/dut/resp_data}
add_wave {/ibex_coherence_tb/dut/snoop_valid}
add_wave {/ibex_coherence_tb/dut/snoop_cmd}
add_wave {/ibex_coherence_tb/dut/snoop_addr}
add_wave {/ibex_coherence_tb/dut/snoop_rsp_valid}
add_wave {/ibex_coherence_tb/dut/snoop_rsp_type}
add_wave {/ibex_coherence_tb/dut/snoop_rsp_data}

# ---------- Core 0 L1 Cache - Control ----------
add_wave_divider "Core 0 L1 Cache - Control"
add_wave {/ibex_coherence_tb/dut/g_cache[0]/u_l1/st_q}
add_wave {/ibex_coherence_tb/dut/g_cache[0]/u_l1/st_d}
add_wave {/ibex_coherence_tb/dut/g_cache[0]/u_l1/ret_q}
add_wave {/ibex_coherence_tb/dut/g_cache[0]/u_l1/req_addr_q}
add_wave {/ibex_coherence_tb/dut/g_cache[0]/u_l1/req_we_q}
add_wave {/ibex_coherence_tb/dut/g_cache[0]/u_l1/pend_req_q}
add_wave {/ibex_coherence_tb/dut/g_cache[0]/u_l1/c_hit}
add_wave {/ibex_coherence_tb/dut/g_cache[0]/u_l1/c_state}
add_wave {/ibex_coherence_tb/dut/g_cache[0]/u_l1/snoop_can_take}
add_wave {/ibex_coherence_tb/dut/g_cache[0]/u_l1/snoop_rsp_valid_o}
add_wave {/ibex_coherence_tb/dut/g_cache[0]/u_l1/snoop_rsp_type_o}

# ---------- Core 1 L1 Cache - Control ----------
add_wave_divider "Core 1 L1 Cache - Control"
add_wave {/ibex_coherence_tb/dut/g_cache[1]/u_l1/st_q}
add_wave {/ibex_coherence_tb/dut/g_cache[1]/u_l1/st_d}
add_wave {/ibex_coherence_tb/dut/g_cache[1]/u_l1/ret_q}
add_wave {/ibex_coherence_tb/dut/g_cache[1]/u_l1/req_addr_q}
add_wave {/ibex_coherence_tb/dut/g_cache[1]/u_l1/req_we_q}
add_wave {/ibex_coherence_tb/dut/g_cache[1]/u_l1/pend_req_q}
add_wave {/ibex_coherence_tb/dut/g_cache[1]/u_l1/c_hit}
add_wave {/ibex_coherence_tb/dut/g_cache[1]/u_l1/c_state}
add_wave {/ibex_coherence_tb/dut/g_cache[1]/u_l1/snoop_can_take}
add_wave {/ibex_coherence_tb/dut/g_cache[1]/u_l1/snoop_rsp_valid_o}
add_wave {/ibex_coherence_tb/dut/g_cache[1]/u_l1/snoop_rsp_type_o}

# ---------- Important Line 0 States ----------
add_wave_divider "Important Line 0 States"
add_wave {/ibex_coherence_tb/dut/g_cache[0]/u_l1/state_q[0]}
add_wave {/ibex_coherence_tb/dut/g_cache[0]/u_l1/tag_q[0]}
add_wave {/ibex_coherence_tb/dut/g_cache[0]/u_l1/data_q[0]}
add_wave {/ibex_coherence_tb/dut/g_cache[1]/u_l1/state_q[0]}
add_wave {/ibex_coherence_tb/dut/g_cache[1]/u_l1/tag_q[0]}
add_wave {/ibex_coherence_tb/dut/g_cache[1]/u_l1/data_q[0]}
add_wave {/ibex_coherence_tb/dut/u_dir/dstate_q[0]}
add_wave {/ibex_coherence_tb/dut/u_dir/sharers_q[0]}
add_wave {/ibex_coherence_tb/dut/u_dir/mem_q[0]}

# ---------- Directory Controller - Control ----------
add_wave_divider "Directory Controller - Control"
add_wave {/ibex_coherence_tb/dut/u_dir/st_q}
add_wave {/ibex_coherence_tb/dut/u_dir/st_d}
add_wave {/ibex_coherence_tb/dut/u_dir/rr_q}
add_wave {/ibex_coherence_tb/dut/u_dir/win_val}
add_wave {/ibex_coherence_tb/dut/u_dir/win_id}
add_wave {/ibex_coherence_tb/dut/u_dir/cur_core_q}
add_wave {/ibex_coherence_tb/dut/u_dir/cur_type_q}
add_wave {/ibex_coherence_tb/dut/u_dir/cur_addr_q}
add_wave {/ibex_coherence_tb/dut/u_dir/cur_li_q}
add_wave {/ibex_coherence_tb/dut/u_dir/owner_q}
add_wave {/ibex_coherence_tb/dut/u_dir/inv_pend_q}
add_wave {/ibex_coherence_tb/dut/u_dir/resp_msg_q}
add_wave {/ibex_coherence_tb/dut/u_dir/resp_data_q}

# ---------- Dinh dang hien thi ----------
# Doi radix sang hex cho de doc (ap dung cho cac signal da them)
foreach w [get_waves *] {
  catch { set_property RADIX hex $w }
}

puts "=== Da them xong toan bo signal B2. Go: restart ; run 500 ns ==="
